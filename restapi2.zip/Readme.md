# API token for simple authentication, Use inside header

name::  x-api-key
value::  5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE
Example::  header( 'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE');

==========================================================================================
# Get Subscribers
Method:: GET

/api/user/2 

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/api/user',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE',
    'Cookie: PHPSESSID=46d07afv33geucfm6em77po4vo'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

?>
==========================================================================================
# Get Single Subscriber
Method:: GET

/api/user/2 

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/api/user/2',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_POSTFIELDS => array('name' => 'Arvind','email' => 'user@gmail.com','_method' => 'DELETE'),
  CURLOPT_HTTPHEADER => array(
    'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE',
    'Cookie: PHPSESSID=40qng6pnqjivfmqph2m6o1tbd3'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
===========================================================================================

# Add Subscriber
Method:: POST
/api/user/

form_data in array
$arr=['name'=>'Arvind Parkash','email'=>'arvind@gmail.com']

Example

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/api/user',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('name' => 'Arvind','email' => 'user1@gmail.com'),
  CURLOPT_HTTPHEADER => array(
    'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE',
    'Cookie: PHPSESSID=40qng6pnqjivfmqph2m6o1tbd3'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

========================================================================================
# update Subscriber
Method:: POST
_method::  PUT
/api/user/1

form_data in array
$arr=['name'=>'Arvind Parkash','email'=>'arvind@gmail.com','_method'=>'PUT']

Example

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/restapi/api/user/4',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('name' => 'User','email' => 'user1@gmail.com','_method' => 'PUT'),
  CURLOPT_HTTPHEADER => array(
    'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE',
    'Cookie: PHPSESSID=40qng6pnqjivfmqph2m6o1tbd3'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

============================================================================================

# DELETE Subscriber

Method:: POST
_method::  DELETE
/api/user/1

form_data in array
$arr=['name'=>'Arvind Parkash','email'=>'arvind@gmail.com','_method'=>'DELETE']

Example

<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'http://localhost/restapi/api/user/4',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('_method' => 'DELETE'),
  CURLOPT_HTTPHEADER => array(
    'x-api-key: 5bCbNTZtmyB8pSPrDSc6Wu2nN25WSXaWQlZ7KuGCgE',
    'Cookie: PHPSESSID=40qng6pnqjivfmqph2m6o1tbd3'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
